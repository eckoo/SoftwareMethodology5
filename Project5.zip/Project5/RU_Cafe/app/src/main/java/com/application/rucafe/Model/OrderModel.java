package com.application.rucafe.Model;

/**
 * This Model class provides the functionality of Model of Order.
 * Every Thing of Order.
 * Like name, type, flavour, quantity, price and sizes of Coffee & Donut
 *
 */
public class OrderModel {

    /**
     * Model For Saving Cart Products
     */
    String name,type,flavour,qty,price,size;

    public OrderModel(String name, String type, String flavour, String qty, String price, String size) {
        this.name = name;
        this.type = type;
        this.flavour = flavour;
        this.qty = qty;
        this.price = price;
        this.size = size;
    }

    public OrderModel() {
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFlavour() {
        return flavour;
    }

    public void setFlavour(String flavour) {
        this.flavour = flavour;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
