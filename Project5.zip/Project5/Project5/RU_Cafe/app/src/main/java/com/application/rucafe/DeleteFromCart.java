package com.application.rucafe;

/**
 * Interface in which we use function
 *
 * @author Kiernan King and Ahmed Alghazwi
 */
public interface DeleteFromCart {
    void onclick();
}
